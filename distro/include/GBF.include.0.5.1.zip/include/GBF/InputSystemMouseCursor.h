#ifndef _INPUTSYSTEMMOUSECURSOR_H
#define _INPUTSYSTEMMOUSECURSOR_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "GraphicSystemImage.h"
#include <string>

#include "GBF_define.h"

//*
// * \class InputSystemMouseCursor
// * \brief Representa��o do cursor do mouse na tela
// * \date 15/04/2005
// * \warning nenhum

class InputSystemMouseCursor : public GraphicSystemImage {
  public:
    //* Destrutor 
    virtual ~InputSystemMouseCursor();

    virtual bool carregarArquivo(std::string arquivo);


  protected:
    void desenhar(int x, int y);


  private:
    //* Construtor 
    InputSystemMouseCursor();

    Ponto ponto;

  friend class InputSystemMouse;
};
#endif
