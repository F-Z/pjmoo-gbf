#ifndef _TOPSYSTEMGALERIA_H
#define _TOPSYSTEMGALERIA_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "TopSystemRecorde.h"
#include "TopSystemRecordeLista.h"
#include <string>


class TopSystemGaleria {
  public:
    TopSystemGaleria();

    ~TopSystemGaleria();

    // Adiciona um recorde
    bool adicionar(TopSystemRecorde recorde);

    // Retorna um recorde com base no indice
    TopSystemRecorde getRecorde(int indice);

    // Salva recordes em disco
    bool salvar();

    // Carrega recordes
    bool carregar();

    void setRecordeLista(TopSystemRecordeLista lista);

    void setArquivo(std::string arquivo);

    static void setPathBase(std::string path);

    void setAssinatura(int jogoNome, int jogoSigla, int jogoVersao);

    bool pesquisar(TopSystemRecorde pesquisa);


  protected:
    std::string arquivo;

    TopSystemRecordeLista lista;


  private:
    static const int assCheckSize =  3;

    static int assCheck[assCheckSize];

    static std::string pathBase;

};
#endif
