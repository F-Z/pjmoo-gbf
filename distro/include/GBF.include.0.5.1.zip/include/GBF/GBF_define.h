#ifndef _GBF_DEFINE_H
#define _GBF_DEFINE_H

//SDL
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>


////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

//Defini��o para posicionamento
struct Ponto {
    int x;

    int y;

};
// Defini��o de Dimensao
struct Dimensao {
    int w;

    int h;

};
//* Defini��o para o tipo Cor 
typedef Uint32 Cor;
//* Defini��o para o paleta de Cor (Canal R,G,B) 
typedef Uint8 CorPaleta;
//Defini��o para posicionamento Virtual
struct PontoVirtual {
    float x;

    float y;

};
#endif
