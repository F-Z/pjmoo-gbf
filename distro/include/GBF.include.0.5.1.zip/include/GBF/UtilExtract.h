#ifndef _UTILEXTRACT_H
#define _UTILEXTRACT_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include <string>


//Descri��o: 
//    Classe utilit�ria para extra��o de informa��es relativas ao path de arquivos
//Motiva��o:
//    Descobrir caminhos de pastas
//    Extrair o nome de aplicativos
class UtilExtract {
  public:
    //Extrai o caminho do diret�rio base 
    static std::string extractPath(char * fullPath);

    //Extrai o nome do aplicativo
    static std::string extractApplication(char * fullPath);

};
#endif
