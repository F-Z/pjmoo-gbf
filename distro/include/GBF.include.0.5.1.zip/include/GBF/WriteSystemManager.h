#ifndef _WRITESYSTEMMANAGER_H
#define _WRITESYSTEMMANAGER_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "WriteSystemBitmap.h"
#include <string>

#include <map>

#include "WriteSystemFontDefault.h"

//Classe para gerenciamento de WriteSystemBitmap (Letras) carregadas
class WriteSystemManager
{
  public:
    virtual ~WriteSystemManager();

    // Retorna uma Fonte para Manipula��o
    WriteSystemBitmap * getFonte(std::string nome);

    //Pega uma Inst�ncia de FonteManager
    static WriteSystemManager * getInstance();

    void carregar(std::string nome, std::string arquivo);

    void escrever(std::string nome, int X, int Y, const char * TEXTO, ...);

    // Remove do FonteManager 
    void apagar(std::string nome);


  protected:
    static WriteSystemManager * instance;

    std::map<std::string,WriteSystemBitmap*> objetomap;


  private:
    WriteSystemManager();


};
#endif
