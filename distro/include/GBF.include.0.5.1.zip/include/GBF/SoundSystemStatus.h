#ifndef _SOUNDSYSTEMSTATUS_H
#define _SOUNDSYSTEMSTATUS_H


#include <string> // Adicionada para poder usar a palavra reservada NULL

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

class SoundSystemStatus {
  public:
    virtual ~SoundSystemStatus();

    static SoundSystemStatus * getInstance();

    bool isAtivo();

    bool isMute();

    void setMute(bool mute);

    void setAtivo(bool ativo);


  protected:
    bool ativo;

    bool mute;


  private:
    SoundSystemStatus();

    static SoundSystemStatus * instance;

};
#endif
