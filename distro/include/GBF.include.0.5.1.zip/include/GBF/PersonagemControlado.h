#ifndef _PERSONAGEMCONTROLADO_H
#define _PERSONAGEMCONTROLADO_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "PersonagemAbstract.h"
#include "SpritePersonagem.h"
#include "InputSystem.h"

//*
// * \class PersonagemControlado
// * \brief Classe abstrata/base para representando personagens do jogador
// * \author David de Almeida Ferreira
// * \date 15/04/2005
// * \warning Classe Abstrata
// 
class PersonagemControlado : public PersonagemAbstract {
  public:
    //* Construtor 
    PersonagemControlado();

    //* Destrutor 
    virtual ~PersonagemControlado();

    bool create(SpritePersonagem * sprite);

    virtual void acao(InputSystem * input) = 0;

};
#endif
