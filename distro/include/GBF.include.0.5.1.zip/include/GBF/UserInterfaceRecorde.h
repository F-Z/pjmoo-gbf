#ifndef _USERINTERFACERECORDE_H
#define _USERINTERFACERECORDE_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "TopSystemRecorde.h"
#include "InputSystem.h"
#include <string>

#include "WriteSystemManager.h"
#include "GraphicSystemGFX.h"
#include "TimerSystemCronometroDecrescente.h"
#include "TimerSystemCronometroCrescente.h"
#include "GBF_define.h"

class UserInterfaceRecorde {
  public:
    // class constructor
    UserInterfaceRecorde();

    // class destructor
    ~UserInterfaceRecorde();

    void setRecorde(TopSystemRecorde recorde);

    TopSystemRecorde getRecorde();

    void setInput(InputSystem * input);

    void setFonteLabel(std::string fonte);

    void setFonteTeclado(std::string fonte);

    void setPosicao(int x, int y);

    void desenhar();

    bool controle();


  protected:
    void navegar();

    bool confirmar();

    void desenharCaixa();

    void desenharMiniTeclado();

    void desenharDados();


  private:
    TopSystemRecorde recorde;

    InputSystem * input;

    WriteSystemManager * wsManager;

    GraphicSystemGFX * gsGFX;

    TimerSystemCronometroDecrescente tempoNavegacao;

    TimerSystemCronometroCrescente tempoBlink;

    char miniTeclado[50];

    int totalTeclasTeclado;

    unsigned int totalTeclasControle;

    int totalTeclas;

    unsigned int tamanhoMaiorTeclaControle;

    int tecladoSelecao;

    int nomePosicao;

    std::string * tecladoControle;

    std::string fonteLabel;

    std::string fonteTeclado;

    Ponto posicao;

    Dimensao dimensaoFonteLabel;

    Dimensao dimensaoFonteTeclado;

    Dimensao caixaTeclado;

};
#endif
