#ifndef _SOUNDSYSTEMMUSICMANAGER_H
#define _SOUNDSYSTEMMUSICMANAGER_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "SoundSystemInterfaceManager.h"
#include <string>

#include <map>

#include "SoundSystemMusic.h"
#include "SoundSystemStatus.h"

//*
// * \class SoundSystemMusicManager
// * \brief Classe para Gerenciamento de M�sica ( SoundSystemMusic )
// * \author David de Almeida Ferreira
// * \author E-Mail: davidferreira@uol.com.br
// * \author ICQ: 21877381
// * \author MSN: davidaf@uol.com.br
// * \author Site Pessoal: http://davidferreira.sites.uol.com.br
// * \author Site do Projeto: http://codigolivre.org.br/projects/pjmoo/
// * \version 1.0
// * \date 24/10/2004
// * \warning nenhum
// * \note
// * \ Padr�es de Projeto:
// * \  -# Singleton
// 
class SoundSystemMusicManager : public SoundSystemInterfaceManager {
  public:
    virtual ~SoundSystemMusicManager();

    virtual void play(std::string nome);

    virtual void carregar(std::string nome, std::string arquivo);

    virtual void apagar(std::string nome);

    virtual void pause();

    virtual void resume();

    void playLoop(std::string nome, int vezes);

    void playInfinity(std::string nome);

    void stop(std::string nome);


  protected:
    std::map<std::string,SoundSystemMusic*> objetomap;


  private:
    SoundSystemMusicManager(SoundSystemStatus * status);

  friend class SoundSystem;
};
#endif
