#ifndef _INPUTSYSTEMKEYBOARD_H
#define _INPUTSYSTEMKEYBOARD_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "UtilLog.h"
#include "GBF_define.h"

//*
// * \class InputSystemKeyboard
// * \brief Classe para manipula��o do Teclado
// * \date 08/11/2004
// * \warning nenhum
// * \note Declaramos a Classe InputSystem como classe friend de InputSystemKeyboard,
// * \note para mantermos encapsulados o metodo Processar, por�m vis�vel para 
// * \note a automatiza��o do InputSystem

class InputSystemKeyboard {
  public:
    //* Destrutor
    virtual ~InputSystemKeyboard();

    //* Verifica se a tecla foi pressionada 
    bool isKey(SDLKey tecla);


  private:
    //* Construtor
    InputSystemKeyboard();

    //* Processa os eventos do teclado 
    void processar();

    //* Limpa o estado das teclas
    void limparEstado();

    static Uint8 * ptecla;

  friend class InputSystem;
};
#endif
