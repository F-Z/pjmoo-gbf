#ifndef _WRITESYSTEMBITMAP_H
#define _WRITESYSTEMBITMAP_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "GraphicSystemImage.h"
#include <string>

#include "GBF_define.h"

//*
// * \class WriteSystemBitmap
// * \brief Classe para Representando de Fontes(Letras)
// * \author David de Almeida Ferreira
// * \author E-Mail: davidferreira@uol.com.br
// * \author ICQ: 21877381
// * \author MSN: davidaf@uol.com.br
// * \author Site Pessoal: http://davidferreira.sites.uol.com.br
// * \author Site do Projeto: http://pjmoo.codigolivre.org.br
// * \version 1.0
// * \date 15/04/2005
// * \warning
// 
class WriteSystemBitmap : public GraphicSystemImage
{
  public:
    //* Destrutor 
    virtual ~WriteSystemBitmap();

    virtual bool carregarArquivo(std::string ARQUIVO);

    void setDimensao(int largura, int altura);

    int getLargura();

    int getAltura();

    Dimensao getDimensao();


  protected:
    void escrever(const char * PALAVRA, int X, int Y);


  private:
    char largura[256];

    Dimensao dimensaoPadrao;

    Dimensao dimensaoQuadro;

    //* Construtor 
    WriteSystemBitmap();

    void checkar();

  friend class WriteSystemManager;

};
#endif
