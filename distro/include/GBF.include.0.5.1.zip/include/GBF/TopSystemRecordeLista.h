#ifndef _TOPSYSTEMRECORDELISTA_H
#define _TOPSYSTEMRECORDELISTA_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "TopSystemRecorde.h"

class TopSystemRecordeLista {
  public:
    //* Adiciona um novo recorde
    bool adicionar(TopSystemRecorde novo);

    //* Pesquisa se o recorde ja existe
    bool pesquisar(TopSystemRecorde pesquisa);

    //* Retorna o Primeiro recorde
    TopSystemRecorde getPrimeiro();

    //* Retorna o �ltimo recorde
    TopSystemRecorde getUltimo();

    //* Retorna um recorde
    TopSystemRecorde getRecorde(int indice);

    static const int tamanho =  10;


  protected:
    TopSystemRecorde recorde[tamanho];

    //* Ordena os recorde, ficando em ordem descrecente
    void ordenar();


  private:
    bool adicionarFinal(TopSystemRecorde novo);

};
#endif
