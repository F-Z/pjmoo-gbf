#ifndef _PARTICLESYSTEMMANAGER_H
#define _PARTICLESYSTEMMANAGER_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "ParticleSystemEfeito.h"
#include <deque>

class ParticleSystemManager {
  private:
    //* Construtor 
    ParticleSystemManager();


  public:
    //* Destrutor 
    ~ParticleSystemManager();

    //* Adiciona Sistema de Particulas
    void adicionar(ParticleSystemEfeito * efeito);

    //* Desenha objetos que estao no container
    void desenhar();

    //* Atualiza Sistema
    void executar();

    //* Retorna a quantidade de elementos 
    int size();

    //* Limpa o container, removendo todos os elementos
    void limpar();

    // Pega uma Inst�ncia de FonteManager 
    static ParticleSystemManager * getInstance();


  protected:
    static ParticleSystemManager * instance;

    std::deque<ParticleSystemEfeito*> lista;
    void removerMorto();

};
#endif
