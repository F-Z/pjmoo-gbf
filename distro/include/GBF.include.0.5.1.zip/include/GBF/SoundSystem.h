#ifndef _SOUNDSYSTEM_H
#define _SOUNDSYSTEM_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "SoundSystemMusicManager.h"
#include "SoundSystemFxManager.h"
#include "SoundSystemStatus.h"
#include "UtilLog.h"
#include "GBF_define.h"

enum SoundSystemCanal {
  CANAL_MONO = 1,
  CANAL_STEREO =2

};
class SoundSystem {
  public:
    virtual ~SoundSystem();

    static SoundSystem * getInstance();

    void iniciar(int frequencia, Uint16 formato, SoundSystemCanal canal, Uint16 cache, int quantidadeCanais);

    void setMute(bool mute);

    SoundSystemMusicManager * musicManager;

    SoundSystemFxManager * fxManager;


  protected:
    SoundSystemStatus * status;


  private:
    SoundSystem();

    static SoundSystem * instance;

};
#endif
