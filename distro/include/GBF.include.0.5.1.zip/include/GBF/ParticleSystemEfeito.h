#ifndef _PARTICLESYSTEMEFEITO_H
#define _PARTICLESYSTEMEFEITO_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "GBF_define.h"
#include "UtilColor.h"
#include <deque>
#include "GraphicSystem.h"

struct Particula {
    PontoVirtual velocidade;

    PontoVirtual posicao;

    int energia;

    HSV cor;

    bool ativa;

};
class ParticleSystemEfeito {
  public:
    ParticleSystemEfeito();

    virtual ~ParticleSystemEfeito();

    void setQuantidade(int quantidade);

    virtual bool isTerminou();

    virtual void desenhar();

    virtual void criar(int x, int y) = 0;

    virtual void executar() = 0;


  protected:
    std::deque<Particula> lista;
    static GraphicSystem * graphicSystem;

};
#endif
