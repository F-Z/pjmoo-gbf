#ifndef _TIMERSYSTEMCRONOMETROABSTRACT_H
#define _TIMERSYSTEMCRONOMETROABSTRACT_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "GBF_define.h"

//
//CENTESIMO_SEGUNDO =  100,
//MEIO_SEGUNDO      =  500,
//UM_SEGUNDO        = 1000

enum EnumTempo {
  TEMPO_CENTESIMO =100,
  TEMPO_MEIO =500,
  TEMPO_SEGUNDO =1000

};
enum EnumCronometro {
  CRONOMETRO_RESETAR,
  CRONOMETRO_INICIAR,
  CRONOMETRO_PAUSAR,
  CRONOMETRO_CONTINUAR,
  CRONOMETRO_EXECUTAR,
  CRONOMETRO_TERMINAR

};
class TimerSystemCronometroAbstract {
  protected:
    Uint32 tempoUnidade;

    Uint32 tempoInicial;

    Uint32 tempoAtual;

    int tempoCorrente;

    int tempoOriginal;

    EnumCronometro eCronometro;

    virtual void executar() = 0;

    virtual void continuar() = 0;

    virtual void iniciar() = 0;

    virtual void resetar() = 0;

    void execTempoInicial();

    void setExecutar();

    void setTerminar();


  public:
    //* Destrutor 
    virtual ~TimerSystemCronometroAbstract();

    //* Construtor 
    TimerSystemCronometroAbstract();

    void setUnidade(EnumTempo eTempo);

    void setContinuar();

    void setIniciar();

    void setPausar();

    void setResetar();

    void processar();

    int getTempo();

    void setTempoOriginal(int tempo);

    bool isTerminou();

};
#endif
