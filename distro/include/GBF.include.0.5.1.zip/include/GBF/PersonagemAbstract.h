#ifndef _PERSONAGEMABSTRACT_H
#define _PERSONAGEMABSTRACT_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "GBF_define.h"
#include "SpritePersonagem.h"
#include "InputSystem.h"

//Defini��o de TypeDelay
struct TypeDelay {
    float acao;

    float tiroA;

    float tiroB;

    float tiroC;

    float tiroD;

};
//*
// * \class PersonagemAbstract
// * \brief Classe base para representa��o de personagens gen�ricos
// * \author David de Almeida Ferreira
// * \date 15/04/2005
// * \warning Classe Abstrata
// 
class PersonagemAbstract {
  public:
    //* Destrutor 
    virtual ~PersonagemAbstract();

    virtual void desenhar();

    virtual void setAtivo(bool valor);

    virtual void setVivo(bool valor);

    virtual bool isAtivo();

    virtual bool isVivo();

    virtual bool isColisao(PersonagemAbstract * personagem);

    virtual void setPosicao(int X, int Y);

    virtual void setPosicao(Ponto PONTO);

    virtual Ponto getPosicao();

    bool create(SpritePersonagem * novoSprite);

    virtual void acao(InputSystem * input) = 0;


  protected:
    //* Construtor 
    PersonagemAbstract();

    //* Construtor
    PersonagemAbstract(SpritePersonagem * novoSprite);

    SpritePersonagem * sprite;

    SpritePersonagem * sprite_atingido;

    bool ativo;

    bool vivo;

    unsigned int ID;

    Dimensao dimensao;

    TypeDelay delay;

    Ponto posicao;


  private:
    static unsigned int IDgeneretion;

  friend class ListPersonagemAbstract;
};
#endif
