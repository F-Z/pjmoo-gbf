#ifndef _SOUNDSYSTEMMUSIC_H
#define _SOUNDSYSTEMMUSIC_H

#include <SDL/SDL_mixer.h>
////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include <string>


class SoundSystemMusic {
  public:
    virtual ~SoundSystemMusic();

    // Toca M�sica de Fundo 
    void play();

    // Toca M�sica de Fundo v�rias vezes 
    void playLoop(int vezes);

    // Toca M�sica de Fundo de forma infinita, ou sej� n�o para 
    void playInfinity();

    // L� arquivo de m�sica (midi,mp3) 
    bool carregarArquivo(std::string arquivo);

    // Altera o volume do efeito, vai de 0 ate 128 
    void setVolume(int valor);

    void stop();


  protected:
    SoundSystemMusic();

    Mix_Music * musica;

  friend class SoundSystemMusicManager;
};
#endif
