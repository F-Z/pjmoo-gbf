#ifndef _WRITESYSTEMFONTDEFAULT_H
#define _WRITESYSTEMFONTDEFAULT_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include <string>


//*
// * \class WriteSystemFontDefault
// * \brief Mapeamento das Fontes(Letras) Padr�es
// * \author David de Almeida Ferreira
// * \author E-Mail: davidferreira@uol.com.br
// * \author ICQ: 21877381
// * \author MSN: davidaf@uol.com.br
// * \author Site Pessoal: http://davidferreira.sites.uol.com.br
// * \author Site do Projeto: http://codigolivre.org.br/projects/pjmoo/
// * \version 1.0
// * \date 13/11/2004
// * \warning Classe Est�tica
// 
class WriteSystemFontDefault
{
  public:
    static std::string console;

    static std::string pumpdemi;

    static std::string fixedsys;

    static std::string arial;

    static std::string comic;

    static std::string high;

    static std::string stac;


};
#endif
