#ifndef _TIMERSYSTEMFPS_H
#define _TIMERSYSTEMFPS_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "UtilLog.h"
#include "GBF_define.h"

class TimerSystemFPS {
  public:
    TimerSystemFPS();

    virtual ~TimerSystemFPS();

    void processar();

    void start();

    //* Aumenta a frequencia do FPS
    void aumentar();

    //* Diminui a frequencia do FPS
    void diminuir();


  protected:
    Uint32 getDelay();


  private:
    double framestart;

    int fpsMax;

};
#endif
