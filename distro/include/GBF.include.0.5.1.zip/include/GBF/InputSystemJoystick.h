#ifndef _INPUTSYSTEMJOYSTICK_H
#define _INPUTSYSTEMJOYSTICK_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "UtilLog.h"
#include "GBF_define.h"

// Direcional do Joystick
enum JOYSTICK_AXE {
  AXE_STOP,
  AXE_LEFT,
  AXE_RIGHT,
  AXE_UP,
  AXE_DOWN

};
//* Bot�es do Joystick 
enum JOYSTICK_BOTAO {
  JB_A,
  JB_B,
  JB_C,
  JB_D

};
//*
// * \class InputSystemJoystick
// * \brief Classe para manipula��o de Joystick
// * \date 08/11/2004
// * \warning nenhum
// * \note Declaramos a Classe InputSystem como classe friend de InputSystemJoystick ,
// * \note para mantermos encapsulados o metodo Processar, por�m vis�vel para 
// * \note a automatiza��o do InputSystem

class InputSystemJoystick {
  public:
    //* Destrutor 
    virtual ~InputSystemJoystick();

    //* Retorna se o direcional foi movido para o lado esquerdo 
    bool isAxeLeft();

    //* Retorna se o direcional foi movido para o lado direito 
    bool isAxeRight();

    //* Retorna se o direcional foi movido para cima 
    bool isAxeUp();

    //* Retorna se o direcional foi movido para baixo 
    bool isAxeDown();

    //* Retorna se o bot�o A foi pressionado 
    bool isButtonA();

    //* Retorna se o bot�o B foi pressionado 
    bool isButtonB();

    //* Retorna se o bot�o C foi pressionado (caso exista) 
    bool isButtonC();

    //* Retorna se o bot�o D foi pressionado (caso exista) 
    bool isButtonD();


  private:
    //* Construtor 
    InputSystemJoystick();

    //* Processa os eventos do joystick 
    void processar();

    //* Limpa o estado das teclas
    void limparEstado();

    SDL_Joystick * joystick;

    JOYSTICK_AXE axe_horizontal;

    JOYSTICK_AXE axe_vertical;

  friend class InputSystem;
};
#endif
