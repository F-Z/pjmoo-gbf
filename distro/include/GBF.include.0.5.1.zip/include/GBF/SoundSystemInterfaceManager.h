#ifndef _SOUNDSYSTEMINTERFACEMANAGER_H
#define _SOUNDSYSTEMINTERFACEMANAGER_H

////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2006 David de Almeida Ferreira
////    
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////    
////    David Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.codigolivre.org.br
////////////////////////////////////////////////////////////////////////

#include "SoundSystemStatus.h"
#include <string>

#include "UtilLog.h"

//*
// * \class SoundSystemInterfaceManager
// * \brief Classe Abstrata para cria��o dos Gerenciadores( Managers ) de Som
// * \author David de Almeida Ferreira
// * \author E-Mail: davidferreira@uol.com.br
// * \author ICQ: 21877381
// * \author MSN: davidaf@uol.com.br
// * \author Site Pessoal: http://davidferreira.sites.uol.com.br
// * \author Site do Projeto: http://codigolivre.org.br/projects/pjmoo/
// * \version 1.0
// * \date 24/10/2004
// * \warning nenhum
// 
class SoundSystemInterfaceManager {
  public:
    SoundSystemInterfaceManager(SoundSystemStatus * status);

    virtual ~SoundSystemInterfaceManager();

    // Toca som
    virtual void play(std::string nome) = 0;

    // Carrega no manager o arquivo de som especificado associando uma chave
    virtual void carregar(std::string nome, std::string ARQUIVO) = 0;

    // Apaga o arquivo de som do manager
    virtual void apagar(std::string nome) = 0;

    // Pausa o sistema de som
    virtual void pause() = 0;

    // Resume, continua a tocar o som
    virtual void resume() = 0;

    // Informa PathBase para leitura de arquivos
    static void setPathBase(std::string path);


  protected:
    SoundSystemStatus * status;

    static std::string pathBase;

};
#endif
