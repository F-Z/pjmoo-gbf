////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2008 David de Almeida Ferreira
////
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////
////    David de Almeida Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.sourceforge.net
////        http://davidferreira-fz.blogspot.com
////////////////////////////////////////////////////////////////////////

#ifndef _SOUNDSTATUS_H
#define _SOUNDSTATUS_H

#include <string> // Adicionada para poder usar a palavra reservada NULL
namespace GBF {

namespace Kernel {

namespace Sound {

//Descri��o: 
//    Classe para controle do estado do sistema de som
//Motiva��o:
//    Fornecer um conjunto de controles b�sicos para o sistema de som
class SoundStatus {
  public:
    //Destrutor
    virtual ~SoundStatus();

    //Verifica se sistema de som est� funcionando
    bool isAtivo();

    //Verifica se o som est� desligado
    bool isMute();

    //Configurar se o sistema de som est� funcionando
    void setAtivo(bool ativo);

    //Configura o sistema de som
    void setMute(bool mute);


  protected:
    bool ativo;

    bool mute;


  private:
    //Construtor
    SoundStatus();

  friend class SoundCore;
};

} // namespace GBF::Kernel::Sound

} // namespace GBF::Kernel

} // namespace GBF
#endif
