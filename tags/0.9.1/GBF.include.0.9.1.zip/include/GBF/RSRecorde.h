////    GBF - Gamework's Brazilian Framework
////    Copyright (C) 2004-2008 David de Almeida Ferreira
////
////    This library is free software; you can redistribute it and/or
////    modify it under the terms of the GNU Library General Public
////    License as published by the Free Software Foundation; either
////    version 2 of the License, or (at your option) any later version.
////
////    David de Almeida Ferreira (F-Z)
////        davidferreira@uol.com.br or davidferreira.fz@gmail.com
////        http://pjmoo.sourceforge.net
////        http://davidferreira-fz.blogspot.com
////////////////////////////////////////////////////////////////////////

#ifndef _RSRECORDE_H
#define _RSRECORDE_H

#include <string>
namespace RankingSystem {

//Descri��o: 
//    Classe para representar um registro
//Motiva��o:
//    Armazenar informa��es sobre o pontua��o do jogo
struct RSRecorde
{
    unsigned int id;

    char nome[11];

    unsigned int pontos;

    char dataPublicacao[11];

    char tipo[6];

    unsigned int fase;

    unsigned int tempo;

    void inicializar();

};

} // namespace RankingSystem
#endif
